<?php $__env->startSection('mainSection'); ?>

<!--banner-->
<div class="banner-top">
    <div class="container">
        <h3>Checkout</h3>
        <h4><a href="index.html">Home</a><label>/</label>Checkout</h4>
        <div class="clearfix"> </div>
    </div>
</div>
<div class="container text-left mt-5" style="margin-top: 40px">
    <?php if(\Session::has('success_message')): ?>
        <div class="alert alert-success">
            <?php echo \Session::get('success_message'); ?>


        </div>
    <?php endif; ?>
    <?php if(\Session::has('danger_message')): ?>
        <div class="alert alert-success">
            <?php echo \Session::get('danger_message'); ?>

        </div>
    <?php endif; ?>
</div>

<!-- contact -->
<div class="check-out">
    <div class="container">

        <div class="spec ">
            <h3>Checkout</h3>
            <div class="ser-t">
                <b></b>
                <span><i></i></span>
                <b class="line"></b>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <form action="" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter name" value="<?php echo e(Auth::user()->name); ?>">
                    </div>
                    <div class="form-group">
                        <label for="name">Mobile</label>
                        <input type="text" class="form-control" id="name" name="mobile" placeholder="Enter Mobile">
                    </div>
                    <div class="form-group">
                        <label for="name">Address</label>
                        <input type="text" class="form-control" id="name" name="mobile" placeholder="Enter Address">
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>

            <div class="col-md-6">
        <table class="table ">
            <tr>

                <th class="t-head head-it ">Products</th>
                <th class="t-head">Price</th>
                <th class="t-head">Quantity</th>
                <th class="t-head">Total</th>

            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $product = App\Models\Product::find($cartItem->id);
            ?>
            <tr>

                <td class="">

                        <h5><?php echo e($product->name); ?></h5>

                </td>
                <td class="t-data"><?php echo e($cartItem->price); ?></td>
                <td class="t-data">
                        <?php echo e($cartItem->quantity); ?>


                </td>
                <td class="t-data"><?php echo e($cartItem->price * $cartItem->quantity); ?></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" class="text-center">
                    <h3>No Product Found</h3>
                </td>
            </tr>
            <?php endif; ?>
            <tr>

                <th class="t-head head-it "></th>
                <th class="t-head"></th>
                <th class="t-head">Grand Total</th>
                <th class="t-head"><?php echo e(\Cart::getTotal()); ?></th>

            </tr>
        </table>
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamppEight\htdocs\Twoinsoft-Laravel-b245\class-31\bigstore\resources\views/frontend/checkout.blade.php ENDPATH**/ ?>