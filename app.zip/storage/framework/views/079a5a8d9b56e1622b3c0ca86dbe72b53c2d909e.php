<?php $__env->startSection('mainSection'); ?>

<!--banner-->
<div class="banner-top">
    <div class="container">
        <h3>Cart</h3>
        <h4><a href="index.html">Home</a><label>/</label>Cart</h4>
        <div class="clearfix"> </div>
    </div>
</div>

<!-- contact -->
<div class="check-out">
    <div class="container">
        <div class="spec ">
            <h3>Cart</h3>
            <div class="ser-t">
                <b></b>
                <span><i></i></span>
                <b class="line"></b>
            </div>
        </div>

        <table class="table ">
            <tr>
                <th class="t-head head-it ">Products</th>
                <th class="t-head">Price</th>
                <th class="t-head">Quantity</th>
                <th class="t-head">Total</th>

            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $product = App\Models\Product::find($cartItem->id);
            ?>
            <tr class="cross">
                <td class="ring-in t-data">
                    <a href="single.html" class="at-in">
                        <img src="<?php echo e(asset($product->image)); ?>" class="img-responsive" alt="" width="100">
                    </a>
                    <div class="sed">
                        <h5>Sed ut perspiciatis unde</h5>
                    </div>
                    <div class="clearfix"> </div>
                    <div class="close1"> <i class="fa fa-times" aria-hidden="true"></i></div>
                </td>
                <td class="t-data">$10.00</td>
                <td class="t-data">
                    <div class="quantity">
                        <div class="quantity-select">
                            <div class="entry value-minus">&nbsp;</div>
                            <div class="entry value"><span class="span-1">1</span></div>
                            <div class="entry value-plus active">&nbsp;</div>
                        </div>
                    </div>

                </td>
                <td class="t-data">$10.00</td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" class="text-center">
                    <h3>No Product Found</h3>
                </td>
            </tr>
            <?php endif; ?>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamppEight\htdocs\Twoinsoft-Laravel-b245\class-29\bigstore\resources\views/frontend/cart.blade.php ENDPATH**/ ?>