<?php $__env->startSection('mainSection'); ?>
    <div class="banner-top">
        <div class="container">
            <h3 ><?php echo e($subCategory->name); ?>'s Products</h3>
            <h4><a href="<?php echo e(url('/')); ?>">Home</a><label>/</label><?php echo e($subCategory->name); ?>'s Products</h4>
            <div class="clearfix"> </div>
        </div>
    </div>

    <div class="content-top offer-w3agile">
        <div class="container ">
                <div class="spec ">
                    <h3><?php echo e($subCategory->name); ?>'s Products</h3>
                        <div class="ser-t">
                            <b></b>
                            <span><i></i></span>
                            <b class="line"></b>
                        </div>
                </div>
                            <div class=" con-w3l wthree-of">
                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <div class="col-md-3 pro-1">
                                    <div class="col-m">
                                    <a href="<?php echo e(url('product-details/'.$product->id)); ?>" class="offer-img">
                                            <img src="<?php echo e(asset($product->image)); ?>" class="img-responsive" alt="">
                                        </a>
                                        <div class="mid-1">
                                            <div class="women">
                                                <h6><a href="<?php echo e(url('product-details/'.$product->id)); ?>"><?php echo e($product->name); ?></h6>
                                            </div>
                                            <div class="mid-2">
                                                <p ><label><?php echo e($product->price); ?></label><em class="item_price"><?php echo e($product->discounted_price); ?></em></p>

                                                <div class="clearfix"></div>
                                            </div>
                                                <div class="add add-2">
                                               <a href="<?php echo e(url('product-details/'.$product->id)); ?>"> <button class="btn btn-danger my-cart-btn my-cart-b" data-id="1" data-name="product 1" data-summary="summary 1" data-price="6.00" data-quantity="1" data-image="<?php echo e(asset('frontend/')); ?>/images/of16.png">View Details</button></a>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="text-center">
                                    <h3>No  Product Found</h3>
                                </div>
                                <?php endif; ?>



                                <div class="clearfix"></div>
                            </div>
                        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("frontend.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamppEight\htdocs\Twoinsoft-Laravel-b245\class-30\bigstore\resources\views/frontend/category-wise-product.blade.php ENDPATH**/ ?>