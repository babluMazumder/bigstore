<?php $__env->startSection('mainSection'); ?>

<!--banner-->
<div class="banner-top">
    <div class="container">
        <h3>Cart</h3>
        <h4><a href="index.html">Home</a><label>/</label>Cart</h4>
        <div class="clearfix"> </div>
    </div>
</div>
<div class="container text-left mt-5" style="margin-top: 40px">
    <?php if(\Session::has('success_message')): ?>
        <div class="alert alert-success">
            <?php echo \Session::get('success_message'); ?>


        </div>
    <?php endif; ?>
    <?php if(\Session::has('danger_message')): ?>
        <div class="alert alert-success">
            <?php echo \Session::get('danger_message'); ?>

        </div>
    <?php endif; ?>
</div>

<!-- contact -->
<div class="check-out">
    <div class="container">
        <div class="spec ">
            <h3>Cart</h3>
            <div class="ser-t">
                <b></b>
                <span><i></i></span>
                <b class="line"></b>
            </div>
        </div>

        <table class="table ">
            <tr>

                <th class="t-head head-it ">Products</th>
                <th class="t-head">Price</th>
                <th class="t-head">Quantity</th>
                <th class="t-head">Total</th>
                <th class="t-head head-it ">Action</th>

            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $product = App\Models\Product::find($cartItem->id);
            ?>
            <tr>

                <td class="">
                    <a href="single.html" class="at-in">
                        <img src="<?php echo e(asset($product->image)); ?>" class="img-responsive" alt="" width="100">
                    </a>
                    <div class="sed">
                        <h5><?php echo e($product->name); ?></h5>
                    </div>
                    <div class="clearfix"> </div>
                    <div class="close1"> <i class="fa fa-times" aria-hidden="true"></i></div>
                </td>
                <td class="t-data"><?php echo e($cartItem->price); ?></td>
                <td class="t-data">
                    <div class="quantity">
                        <div class="quantity-select">
                            <form action="<?php echo e(url('update-cart')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($cartItem->id); ?>">
                                <input type="number"  name="quantity" value="<?php echo e($cartItem->quantity); ?>" min="1">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </form>
                        </div>
                    </div>

                </td>
                <td class="t-data"><?php echo e($cartItem->price * $cartItem->quantity); ?></td>
                <td>
                    <a href="<?php echo e(url('remove/'.$cartItem->id)); ?>" class="btn btn-danger btn-sm">Remove</a>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" class="text-center">
                    <h3>No Product Found</h3>
                </td>
            </tr>
            <?php endif; ?>
            <tr>

                <th class="t-head head-it "></th>
                <th class="t-head"></th>
                <th class="t-head">Grand Total</th>
                <th class="t-head"><?php echo e(\Cart::getTotal()); ?></th>
                <th class="t-head head-it "></th>

            </tr>
        </table>
        <div class="row">
            <div class="col-md-6">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-primary">Continue Shopping</a>

            </div>
            <div class="col-md-6 text-right">
                <a href="<?php echo e(url('/checkout')); ?>" class="btn btn-success">Checkout</a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamppEight\htdocs\Twoinsoft-Laravel-b245\class-30\bigstore\resources\views/frontend/cart.blade.php ENDPATH**/ ?>