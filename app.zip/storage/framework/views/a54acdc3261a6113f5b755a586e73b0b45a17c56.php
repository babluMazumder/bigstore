<?php $__env->startSection('mainContent'); ?>
<div class="dashboard-wrapper">
    <div class="container-fluid  dashboard-content">
        <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <div class="page-breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>" class="breadcrumb-link">Dashboard</a></li>
                                <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Category List</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->



            <div class="row">
                <!-- ============================================================== -->
                <!-- contextual table -->
                <!-- ============================================================== -->
                <div class="col-12">
                    <div class="card">
                        <div class="row" style="padding: 10px 20px 0px 20px;">
                            <div class="col-md-6">
                                <h5 class="">Category List</h5>
                            </div>
                            <div class="col-md-6 text-right">
                                <a href="<?php echo e(url('category/add-new')); ?>" class="btn btn-primary">Add New</a>
                            </div>
                        </div>


                        <div class="card-body">
                            <?php if(\Session::has('success_message')): ?>
                                <div class="alert alert-success">
                                    <?php echo \Session::get('success_message'); ?>


                                </div>
                            <?php endif; ?>
                            <?php if(\Session::has('danger_message')): ?>
                                <div class="alert alert-success">
                                    <?php echo \Session::get('danger_message'); ?>

                                </div>
                            <?php endif; ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Category Name</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr class="table-primary">
                                        <th scope="row"><?php echo e(++$key); ?></th>
                                        <td><?php echo e($category->name); ?></td>
                                        <td>
                                            <?php if($category->status == 1): ?>
                                                <button class="btn btn-success">Active</button>
                                            <?php else: ?>
                                                <button class="btn btn-warning">Inactive</button>
                                            <?php endif; ?>
                                        </td>
                                        <td><a href="<?php echo e(url('category/edit', $category->id)); ?>" class="btn btn-info">Edit</a><a onclick="return confirm('Are you sure to delete this item.?')" href="<?php echo e(url('category/delete', $category->id)); ?>" class="btn btn-danger">Delete</a></td>
                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

    </div>
    <!-- ============================================================== -->
    <!-- footer -->
    <!-- ============================================================== -->
    <div class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                    Copyright © 2018 Concept. All rights reserved. Dashboard by <a href="https://colorlib.com/wp/">Colorlib</a>.
                </div>
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                    <div class="text-md-right footer-links d-none d-sm-block">
                        <a href="javascript: void(0);">About</a>
                        <a href="javascript: void(0);">Support</a>
                        <a href="javascript: void(0);">Contact Us</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- end footer -->
    <!-- ============================================================== -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamppEight\htdocs\Twoinsoft-Laravel-b245\class-32\bigstore\resources\views/backend/category/index.blade.php ENDPATH**/ ?>